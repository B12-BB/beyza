﻿using System;
using System.Collections.Specialized;

namespace finalproje
{
    // kütüphane kullanıcısının bilgilerinin yazdırılmasını sağlayan arayüz
     interface Ikütüphanekullanıcıları
    {
        void BilgiYazdir();
    }
    // Ikütüphanekullanıcıları arayüzünü uygular.
     public class üye1 : Ikütüphanekullanıcıları 
    {
        // Ad özelliği
        protected string Ad = "Beyza";
        // kitap sayısı özelliği
        protected int Kitaps = 12;
        // Cinsiyet özelliği
        protected string Cinsiyet = "Kadın";
        public virtual void BilgiYazdir()
        {
           
            Console.WriteLine("Ad: " + Ad);// Adı yazdır
            Console.WriteLine("Alınan kitap sayısı: " + Kitaps); // Alınan kitap sayısını ekrana yazdırır
            Console.WriteLine("Cinsiyet: " + Cinsiyet);// Cinsiyeti ekrana yazdır
    
        }

    } 
    // üye1 sınıfının metodlarını kalıtır
      class alınankitaplar :üye1
    {
        protected string Ad = "Savaş ve barış";
        protected int ID = 221;
        public override void BilgiYazdir()
        {
         
            base.BilgiYazdir();
            Console.WriteLine("Kitap Adı: " + Ad);// Adı ekrana yazdır
            Console.WriteLine("Kitap ID: " + ID); // ID değerini ekrana yazdır
            
        }

    }

    // Bir kütüphane kullanıcısını temsil eden sınıf. Ad, yaş, cinsiyet, ve elinde bulunan kitap sayısı gibi özellikleri içerir.
    class VIPüye : Ikütüphanekullanıcıları
    {
        // Ad özelliği
        protected string Ad { get; set; }
        // Yas özelliği
        protected int Yas { get; set; }
        // Cinsiyet özelliği
        protected string Cinsiyet { get; set; }
        // Kitap sayısı özelliği
        protected int Kitaps { get; set; }
        // kiraladığı oda süresi özelliği
        private int kiras { get; set; }
        // Yapılandırıcı metod. Özelliklerin değerlerini ayarlar.
        public VIPüye(string ad, int yas, string cinsiyet, int Kitaps, int kiras)
        {
            this.Ad = ad; // Ad ayarlar
            this.Yas = yas; // Yas değerini ayarlar
            this.Cinsiyet = cinsiyet; // Cinsiyet ayarlar
            this.Kitaps = Kitaps; // Kitap sayısı değerini ayarlar
            this.kiras = kiras; // kira sayısı değerini ayarlar
        }
        // Özelliklerin değerlerini ekrana yazdıran metod
        public void BilgiYazdir()
        {
            Console.WriteLine("VIP Ad: " + Ad);// Adı yazdır
            Console.WriteLine("VIP Yas: " + Yas); // Yası ekrana yazdır
            Console.WriteLine("VIP Cinsiyet: " + Cinsiyet);// Cinsiyeti ekrana yazdır
            Console.WriteLine("VIP Kitap sayısı: " + Kitaps);// Kitap sayısını ekrana yazdır
            Console.WriteLine("VIP Kira süresi:" +kiras);//kiralanan oda süresini ekrana yazdır
        }
    }

    class VIPüye2 : VIPüye
    {
        // Yapılandırıcı metod. VIPüye sınıfının yapılandırıcı metodunu çağırır ve özelliklerin değerlerini ayarlar.
        public VIPüye2(string ad, int yas, string cinsiyet, int Kitaps,int kiras) : base(ad,yas, cinsiyet,Kitaps,kiras)
        {

        }
       
    }

    class Program
    {
        static void Main(string[] args)
        {
            // alınankitaplar sınıfından bir nesne oluştur
            alınankitaplar alınankitaplar = new alınankitaplar();
            // VIPüye sınıfından bir nesne oluştur
            VIPüye VIPüye = new VIPüye("Ali", 30, "Erkek", 15,35);
            // VIPüye2 sınıfından bir nesne oluştur
            VIPüye2 VIPüye2 = new VIPüye2("Hazal",45,"Kdın",22,48);
            
            
            // alınankitaplar nesnesinin BilgiYazdir() metodunu çağır
            alınankitaplar.BilgiYazdir();

            // VIPüye nesnesinin BilgiYazdir() metodunu çağır
            VIPüye.BilgiYazdir();

            // VIPüye2 nesnesinin BilgiYazdir() metodunu çağır
            VIPüye2.BilgiYazdir();

        }
    }
}




